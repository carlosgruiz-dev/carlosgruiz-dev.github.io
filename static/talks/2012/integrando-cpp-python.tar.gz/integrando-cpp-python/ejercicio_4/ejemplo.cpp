#include <boost/python.hpp>
using namespace boost::python;

struct Saludo
    {
        void set(std::string msg) { this->msg = msg; }
        std::string saluda() { return msg; }
        std::string msg;
    };

BOOST_PYTHON_MODULE(ejemplo_ext)
    {
        class_<Saludo>("Saludo")
        .def("saluda", &Saludo::saluda)
        .def("set", &Saludo::set)
        ;
    }

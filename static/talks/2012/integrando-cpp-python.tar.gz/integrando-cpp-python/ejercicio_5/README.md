# Ejercicio 5 

## archivo: bpl.pdf

El documento __"Building Hybrid Systems with Boost.Python"__ es sumamente 
interesante para comprender las ideas y diseño detrás de Boost.Python, no deje
de leerlo.

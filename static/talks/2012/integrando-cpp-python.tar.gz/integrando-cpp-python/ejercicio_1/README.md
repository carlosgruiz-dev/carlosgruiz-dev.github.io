# Ejercicio 1 (Ejemplo de Swig)

Ejemplo sencillo de Swig con C y Python

## ejemplo.c

    /* Variable */
    double mi_variable = 3.0;
    
    /* Calcula el Factorial de n */
    int fact(int n) {
        if (n <= 1) return 1;
        else return n*fact(n-1);
    }

    /* calcula n mod M */
    int mi_mod(int n, int m) {
        return(n % m);
    }

## ejemplo.i

    /* File : ejemplo.i */
    %module ejemplo
    %{
    /* Put headers and other declarations here */
    extern double mi_variable;
    extern int    fact(int);
    extern int    mi_mod(int n, int m);
    %}

    extern double mi_variable;
    extern int    fact(int);
    extern int    mi_mod(int n, int m);

## Construyendo un módulo de Python

    $ swig -python ejemplo.i
    $ gcc -c -fpic ejemplo.c ejemplo_wrap.c -Iusr/include/python2.6
    $ gcc -shared ejemplo.o ejemplo_wrap.o -o _ejemplo.so

## Probando el módulo

    $ python
    Python 2.6.6 (r266:84292, Dec 27 2010, 00:02:40) 
    [GCC 4.4.5] on linux2
    Type "help", "copyright", "credits" or "license" for more information.
    >>> import ejemplo
    >>> ejemplo.fact(4)
    24
    >>> ejemplo.mod(8, 3)
    2
    >>>
 
    
     


/* File : ejemplo.c */

double  mi_variable  = 3.0;

/* Calcula factorial de n */
int  fact(int n) {
	if (n <= 1) return 1;
	else return n*fact(n-1);
}

/* Calcula n mod m */
int mi_mod(int n, int m) {
	return(n % m);
}

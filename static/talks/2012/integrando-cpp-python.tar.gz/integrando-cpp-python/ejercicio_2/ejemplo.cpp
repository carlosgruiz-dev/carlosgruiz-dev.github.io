#include <Python.h>

int
main(int argc, char *argv[])
{
  Py_Initialize();
  PyRun_SimpleString("print 'Hola Mundo!!'");
  Py_Finalize();
  return 0;
}

# Ejercicio 2 (Python Incrustado)

Ejemplo sencillo de C++ ejecutando intrucciones Python

## ejemplo.cpp

    #include <Python.h>

    int
    main(int argc, char *argv[])
    {
        Py_Initialize();
        PyRun_SimpleString("print 'Hola Mundo!!'");
        Py_Finalize();
        return 0;
    }

## Construyendo el programa con Python incrustado

    g++ ejemplo.cpp -o ejemplo -I /usr/include/python2.6 -pthread -lm -ldl -lutil -lpython2.6 

## Probando el programa

    $ ./ejemplo
    Hola Mundo!!
    $

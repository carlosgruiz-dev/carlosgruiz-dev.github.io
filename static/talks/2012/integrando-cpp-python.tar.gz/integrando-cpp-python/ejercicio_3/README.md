# Ejercicio 3 (Extendiendo Python con C++ y Boost)

## ejemplo.cpp

    #include <boost/python/module.hpp>
    #include <boost/python/def.hpp>

    char const* greet()
    {
        return "Hola Mundo!!";
    }

    BOOST_PYTHON_MODULE(ejemplo_ext)
    {
        using namespace boost::python;
        def("greet", greet);
    }

## Construyendo un módulo de Python 

    $ g++ -I/usr/local/include -I/usr/include/python2.6 -fpic -c -o ejemplo_ext.o ejemplo.cpp
    $ g++ -shared -Wl,-soname,"ejemplo_ext.so" -L/usr/local/lib ejemplo_ext.o -lboost_python -fpic -o ejemplo_ext.so

## Probando el módulo de Python

    $ python
    Python 2.6.6 (r266:84292, Dec 27 2010, 00:02:40) 
    [GCC 4.4.5] on linux2
    Type "help", "copyright", "credits" or "license" for more information.
    >>> import ejemplo_ext
    >>> ejemplo_ext.greet()
    'Hola Mundo!!'
    >>> 



from django.contrib.gis import admin
from models import PuntosDeInteres

admin.site.register(PuntosDeInteres, admin.OSMGeoAdmin)

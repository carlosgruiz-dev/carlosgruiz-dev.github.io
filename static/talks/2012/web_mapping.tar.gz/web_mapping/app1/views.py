from django.contrib.gis.shortcuts import render_to_kml

from models import PuntosDeInteres

def kml(request):
    puntos = PuntosDeInteres.objects.kml()
    return render_to_kml("PuntosKML.kml",{"puntos":puntos})

from django.contrib.gis.db import models

# Este es un layer en su mapa para guardar los Puntos De Interes de su
# Aplicacion.

class PuntosDeInteres(models.Model):
    nombre = models.CharField(max_length=50)
    descripcion = models.TextField(blank=True, null=True)

    # Aqui es donde GeoDjango hace su magia negra
    pto = models.PointField()
    objects = models.GeoManager()

    def __unicode__(self):
        return self.nombre

    class Meta():
         verbose_name = "Punto de Interes"
         verbose_name_plural = "Puntos de Interes"
